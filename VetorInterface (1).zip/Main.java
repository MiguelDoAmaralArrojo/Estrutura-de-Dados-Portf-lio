public class Main {
    public static void main(String[] args) {
        ListaEncadeada<Aluno> listaAlunos = new ListaEncadeada<>();
        listaAlunos.inserir(new Aluno("Ana", 20, 9.5));
        listaAlunos.inserir(new Aluno("João", 22, 8.0));
        listaAlunos.inserir(new Aluno("Maria", 21, 7.5));

        System.out.println("Alunos na lista:");
        listaAlunos.imprimir();

        ListaEncadeada<Carro> listaCarros = new ListaEncadeada<>();
        listaCarros.inserir(new Carro("Toyota", "Corolla", 2020));
        listaCarros.inserir(new Carro("Honda", "Civic", 2019));
        listaCarros.inserir(new Carro("Ford", "Fiesta", 2018));

        System.out.println("Carros na lista:");
        listaCarros.imprimir();

    }
}