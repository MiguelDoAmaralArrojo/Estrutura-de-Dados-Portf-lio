import java.util.List;

public class Main {
    public static void main(String[] args) {
        IVetorAluno alunos = new VetorAlunos(3);
        alunos.adiciona(new Aluno("Marcelo Arrojo", 23, 0));
        alunos.adiciona(new Aluno("Raquel Mainardi", 29, 10));
        alunos.adiciona(new Aluno("Miguel", 18, 6.1));
        alunos.adiciona(new Aluno("Leonardo", 19, 7));

        System.out.println("Tamanho do vetor de alunos: " + alunos.tamanho());

        List<Aluno> alunosNotaMenorQue6 = alunos.contemAlunoNotaMenorQue(6.0);
        List<Aluno> alunosNotaMaiorOuIgualA6 = alunos.contemAlunoNotaMaiorOuIgualA(6.0);

        if (!alunosNotaMenorQue6.isEmpty()) {
            System.out.println("Alunos com nota menor que 6:");
            for (Aluno aluno : alunosNotaMenorQue6) {
                System.out.println("Nome: " + aluno.getNome() + ", Nota: " + aluno.getNota());
            }
        } else {
            System.out.println("Nenhum aluno com nota menor que 6 encontrado.");
        }

        if (!alunosNotaMaiorOuIgualA6.isEmpty()) {
            System.out.println("Alunos com nota maior ou igual a 6:");
            for (Aluno aluno : alunosNotaMaiorOuIgualA6) {
                System.out.println("Nome: " + aluno.getNome() + ", Nota: " + aluno.getNota());
            }
        } else {
            System.out.println("Nenhum aluno com nota maior ou igual a 6 encontrado.");
        }
    }
}