// Classe Carro
class Carro {
    private String marca;
    private String modelo;
    private int ano;

    public Carro(String marca, String modelo, int ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }

    @Override
    public String toString() {
        return "Carro: Marca: " + marca + ", Modelo: " + modelo + ", Ano: " + ano;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Carro other = (Carro) obj;
        return ano == other.ano && marca.equals(other.marca) && modelo.equals(other.modelo);
    }
}
