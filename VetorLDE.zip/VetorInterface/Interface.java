interface IVetor<T> {
    void inserir(T valor);
    boolean remover(T valor);
    void imprimirParaFrente();
    void imprimirParaTras();
}