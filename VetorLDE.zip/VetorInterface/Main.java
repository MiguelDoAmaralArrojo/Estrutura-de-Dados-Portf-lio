public class Main {
    public static void main(String[] args) {
        ListaDuplamenteEncadeada<Carro> listaCarros = new ListaDuplamenteEncadeada<>();
        listaCarros.inserir(new Carro("Toyota", "Corolla", 2020));
        listaCarros.inserir(new Carro("Honda", "Civic", 2019));
        listaCarros.inserir(new Carro("Ford", "Fiesta", 2018));

        System.out.println("Carros na lista (frente para trás):");
        listaCarros.imprimirParaFrente();

        System.out.println("\nCarros na lista (trás para frente):");
        listaCarros.imprimirParaTras();

        // Removendo um carro
        Carro carroRemover = new Carro("Honda", "Civic", 2019);
        if (listaCarros.remover(carroRemover)) {
            System.out.println("\nCarro removido: " + carroRemover.toString());
        } else {
            System.out.println("\nCarro não encontrado para remoção.");
        }

        System.out.println("\nCarros na lista após remoção:");
        listaCarros.imprimirParaFrente();

        ListaDuplamenteEncadeada<Aluno> listaAlunos = new ListaDuplamenteEncadeada<>();
        listaAlunos.inserir(new Aluno("Ana", 20, 9.5));
        listaAlunos.inserir(new Aluno("João", 22, 8.0));
        listaAlunos.inserir(new Aluno("Maria", 21, 7.5));

        System.out.println("Alunos na lista (frente para trás):");
        listaAlunos.imprimirParaFrente();

        System.out.println("\nAlunos na lista (trás para frente):");
        listaAlunos.imprimirParaTras();

        // Removendo um aluno
        Aluno alunoRemover = new Aluno("João", 22, 8.0);
        if (listaAlunos.remover(alunoRemover)) {
            System.out.println("\nAluno removido: " + alunoRemover.toString());
        } else {
            System.out.println("\nAluno não encontrado para remoção.");
        }

        System.out.println("\nAlunos na lista após remoção:");
        listaAlunos.imprimirParaFrente();
    }
}