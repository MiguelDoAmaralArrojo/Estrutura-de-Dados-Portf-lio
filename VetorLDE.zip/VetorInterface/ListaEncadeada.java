// Classe ListaDuplamenteEncadeada
class ListaDuplamenteEncadeada<T> implements IVetor<T> {
    private No<T> inicio;
    private No<T> fim;

    public ListaDuplamenteEncadeada() {
        this.inicio = null;
        this.fim = null;
    }

    public void inserir(T valor) {
        No<T> novoNo = new No<>(valor);
        if (inicio == null) {
            inicio = novoNo;
            fim = novoNo;
        } else {
            fim.proximo = novoNo;
            novoNo.anterior = fim;
            fim = novoNo;
        }
    }

    public boolean remover(T valor) {
        No<T> encontrado = buscar(valor);
        if (encontrado != null) {
            if (encontrado == inicio) {
                inicio = inicio.proximo;
                if (inicio != null) {
                    inicio.anterior = null;
                }
            } else if (encontrado == fim) {
                fim = fim.anterior;
                fim.proximo = null;
            } else {
                encontrado.anterior.proximo = encontrado.proximo;
                encontrado.proximo.anterior = encontrado.anterior;
            }
            return true;
        }
        return false;
    }

    public void imprimirParaFrente() {
        No<T> atual = inicio;
        while (atual != null) {
            System.out.println(atual.valor.toString());
            atual = atual.proximo;
        }
    }

    public void imprimirParaTras() {
        No<T> atual = fim;
        while (atual != null) {
            System.out.println(atual.valor.toString());
            atual = atual.anterior;
        }
    }

    private No<T> buscar(T valor) {
        No<T> atual = inicio;
        while (atual != null) {
            if (atual.valor.equals(valor)) {
                return atual;
            }
            atual = atual.proximo;
        }
        return null;
    }
}
